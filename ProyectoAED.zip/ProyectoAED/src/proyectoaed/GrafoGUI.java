/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoaed;

/**
 *
 * @author jossu
 */
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;
import javax.swing.*;
import java.util.*;

public class GrafoGUI {

    // Método para mostrar el grafo con JGraphX
   public static void mostrarGrafo(GrafoDirigidoAciclico grafo) {
    // Crear un grafo de JGraphX
    mxGraph graph = new mxGraph();
    Object parent = graph.getDefaultParent();
    
    // Iniciar la actualización del grafo
    graph.getModel().beginUpdate();
    
    try {
        // Crear un mapa de vértices, ahora con String como clave
        Map<String, Object> vertexMap = new HashMap<>();
        
        // Agregar vértices de Grafo a JGraphX
        for (String vertex : grafo.getListaAdyacencia().keySet()) {
            // Usamos el valor del vértice (String) como etiqueta
            vertexMap.put(vertex, graph.insertVertex(parent, null, vertex, 100 + vertex.hashCode() % 120, 100, 80, 30));
        }

        // Crear aristas de Grafo a JGraphX
        for (String vertex : grafo.getListaAdyacencia().keySet()) {
            // Obtener los vecinos de cada vértice
            for (String vecino : grafo.obtenerVecinos(vertex)) {
                // Crear la arista entre los vértices
                graph.insertEdge(parent, null, "A", vertexMap.get(vertex), vertexMap.get(vecino));
            }
        }

    } finally {
        // Finalizar la actualización
        graph.getModel().endUpdate();
    }




        // Crear un componente para visualizar el grafo
        mxGraphComponent graphComponent = new mxGraphComponent(graph);
        JFrame frame = new JFrame("Visualización del Grafo");
        frame.getContentPane().add(graphComponent);
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // Crear el grafo
        GrafoDirigidoAciclico grafo = new GrafoDirigidoAciclico(5); // Grafo de 5 vértices
        grafo.insertarArista("0","1");
        grafo.insertarArista("1", "2");
        grafo.insertarArista("2", "3");
        grafo.insertarArista("3", "4");

        // Mostrar el grafo usando JGraphX
        mostrarGrafo(grafo);
    }

}


